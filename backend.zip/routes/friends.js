const express = require('express');
const router = express.Router();
const User = require('../models/User');
const verifyToken = require('../middleware/auth');

// Search users
router.get('/search', verifyToken, async (req, res) => {
  const query = req.query.query;
  const users = await User.find({
    $or: [
      { username: { $regex: query, $options: 'i' } },
      { email: { $regex: query, $options: 'i' } }
    ],
    _id: { $ne: req.user.id }
  }).select('username email');
  res.json(users);
});

// Add friend
router.post('/add', verifyToken, async (req, res) => {
  const { friendId } = req.body;
  if (friendId === req.user.id) return res.status(400).send("Can't friend yourself");

  const user = await User.findById(req.user.id);
  if (!user.friends.includes(friendId)) {
    user.friends.push(friendId);
    await user.save();

    const friend = await User.findById(friendId);
    friend.friends.push(req.user.id);
    await friend.save();
  }

  res.json({ message: 'Friend added!' });
});

// Remove friend
router.delete('/remove', verifyToken, async (req, res) => {
  const { friendId } = req.body;

  await User.findByIdAndUpdate(req.user.id, { $pull: { friends: friendId } });
  await User.findByIdAndUpdate(friendId, { $pull: { friends: req.user.id } });

  res.json({ message: 'Friend removed!' });
});

module.exports = router;
