// backend/routes/group.js
const express = require("express");
const router = express.Router();
const Group = require("../models/Group");
const User = require("../models/User");

// Create a group
router.post("/create", async (req, res) => {
  const { groupName, members, createdBy } = req.body;
  try {
    const newGroup = new Group({ groupName, members, createdBy });
    await newGroup.save();
    res.status(201).json({ message: "Group created", group: newGroup });
  } catch (error) {
    res.status(500).json({ error: "Failed to create group" });
  }
});

// Get user's groups
router.get("/user/:userId", async (req, res) => {
  try {
    const groups = await Group.find({ members: req.params.userId });
    res.status(200).json(groups);
  } catch (error) {
    res.status(500).json({ error: "Error getting groups" });
  }
});

// Add member to group (only creator can add)
router.post("/add-member", async (req, res) => {
  const { groupId, memberId, requesterId } = req.body;
  try {
    const group = await Group.findById(groupId);
    if (group.createdBy !== requesterId)
      return res.status(403).json({ error: "Only creator can add members" });

    if (!group.members.includes(memberId)) group.members.push(memberId);
    await group.save();
    res.status(200).json({ message: "Member added", group });
  } catch (error) {
    res.status(500).json({ error: "Failed to add member" });
  }
});

// Remove member from group (only creator)
router.post("/remove-member", async (req, res) => {
  const { groupId, memberId, requesterId } = req.body;
  try {
    const group = await Group.findById(groupId);
    if (group.createdBy !== requesterId)
      return res.status(403).json({ error: "Only creator can remove members" });

    group.members = group.members.filter((id) => id !== memberId);
    await group.save();
    res.status(200).json({ message: "Member removed", group });
  } catch (error) {
    res.status(500).json({ error: "Failed to remove member" });
  }
});

module.exports = router;



                                                                                                                                                                                
