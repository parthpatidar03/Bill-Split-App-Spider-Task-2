const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const multer = require("multer");
const path = require("path");
const router = express.Router();
const verifyToken = require('../middleware/verifyToken.js')

// Register User
router.post('/register', async (req, res) => {
    console.log("req.body is:", req.body);
  const { username, email, password } = req.body;
  const hashedPass = await bcrypt.hash(password, 10);
  const user = new User({ username, email, password: hashedPass });
  await user.save();
  res.json({ message: "User registered successfully" });
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(401).json({ error: "Invalid email" });

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(401).json({ error: "Wrong password" });

  const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
  res.json({ token, user: { username: user.username, email: user.email } });
});

//Profile
router.get('/profile', verifyToken, async (req, res) => {
  const user = await User.findById(req.userId).select('-password');
  res.json(user);
});

// ✅ PUT: Update user info
router.put("/profile", verifyToken, async (req, res) => {
  try {
    const { username, email } = req.body;
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      { username, email },
      { new: true }
    );
    res.json(updatedUser);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// Storage setup for multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // e.g., 123456.jpg
  },
});


const upload = multer({ dest: 'uploads/' });

// ✅ POST: Upload profile image
router.post('/profile/upload', verifyToken, upload.single('profilePic'), async (req, res) => {
  console.log("File received:", req.file); // Debug line

  if (!req.file) {
    return res.status(400).json({ error: 'Upload failed' });
  }

  res.json({ message: "Upload successful", file: req.file });
});

// Test route
router.get('/me', verifyToken, (req, res) => {
  res.json({
    message: 'You are authorized!',
    user: req.user
  });
});

module.exports = router;
