const express = require('express');
const router = express.Router();
const Expense = require('../models/Expense');
const Group = require('../models/Group');

// Create expense
router.post('/add', async (req, res) => {
  const { title, amount, groupId, paidBy } = req.body;
  try {
    const group = await Group.findById(groupId);
    if (!group) return res.status(404).json({ error: "Group not found" });

    const expense = new Expense({
      title,
      amount,
      paidBy,
      group: groupId,
      splitBetween: group.members,
    });

    await expense.save();

    group.expenses.push(expense._id);
    await group.save();

    res.status(201).json({ message: "Expense added", expense });
  } catch (error) {
    res.status(500).json({ error: "Failed to add expense" });
  }
});

// Delete expense
router.delete('/delete/:expenseId', async (req, res) => {
  try {
    const expense = await Expense.findById(req.params.expenseId);
    if (!expense) return res.status(404).json({ error: "Expense not found" });

    await Group.findByIdAndUpdate(expense.group, {
      $pull: { expenses: expense._id }
    });

    await expense.deleteOne();
    res.status(200).json({ message: "Expense deleted" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete expense" });
  }
});

module.exports = router;
