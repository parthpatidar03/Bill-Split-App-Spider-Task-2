const mongoose =require("mongoose");

const UserSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email:    { type: String, required: true, unique: true },
  password: { type: String, required: true }
});

new mongoose.Schema({
    username: String,
    email: String,  
    password: String, // this will be hashed
    friends: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // ref to other users
    profilePic: String,
},{timestamps: true });

module.exports = mongoose.model("User", UserSchema);