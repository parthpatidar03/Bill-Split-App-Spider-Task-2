require('dotenv').config(); 
const express = require("express");
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth.js')
const friendRoutes = require('./routes/friends');

app.use(cors());
app.use(express.json());
app.use('/api/auth',authRoutes)
app.use("/uploads", express.static("uploads")); // Serve image URL
app.use('/api', authRoutes);
app.use('/api/friends', friendRoutes);
app.use("/api/group", require("./routes/group"));
app.use('/api/expense', require('./routes/expense'));


mongoose.connect(process.env.MONGO_URL)
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.error("❌ Mongo error",err));

// Routes
app.use('/api/auth', authRoutes); // ✅ Register auth routes

app.listen(3000, () => console.log("🚀 Server running on port 3000"));