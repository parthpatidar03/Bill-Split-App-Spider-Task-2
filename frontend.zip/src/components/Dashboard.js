import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CreateGroup from './CreateGroup';
import AddExpense from './AddExpense';

const Dashboard = () => {
  const [groups, setGroups] = useState([]);
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const res = await axios.get(`http://localhost:3000/api/group/user/${userId}`);
        setGroups(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchGroups();
  }, [userId]);

  return (
    <div className="dashboard">
      <h2>Your Groups</h2>
      <CreateGroup />
      <AddExpense />
      <ul>
        {groups.map(group => (
          <li key={group._id}>{group.name} ({group.members.length} members)</li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
