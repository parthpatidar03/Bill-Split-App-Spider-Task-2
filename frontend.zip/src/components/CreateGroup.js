import React, { useState } from 'react';
import axios from 'axios';

const CreateGroup = () => {
  const [name, setName] = useState('');
  const [members, setMembers] = useState('');
  const creator = localStorage.getItem('userId');

  const handleCreate = async (e) => {
    e.preventDefault();
    const memberList = members.split(',').map(m => m.trim());
    try {
      await axios.post('http://localhost:3000/api/group/create', {
        name,
        creator,
        members: [creator, ...memberList]
      });
      alert('Group created!');
    } catch {
      alert('Failed to create group');
    }
  };

  return (
    <form onSubmit={handleCreate}>
      <h3>Create Group</h3>
      <input placeholder="Group Name" value={name} onChange={(e) => setName(e.target.value)} required />
      <input placeholder="Other member IDs (comma-separated)" value={members} onChange={(e) => setMembers(e.target.value)} />
      <button type="submit">Create</button>
    </form>
  );
};

export default CreateGroup;
