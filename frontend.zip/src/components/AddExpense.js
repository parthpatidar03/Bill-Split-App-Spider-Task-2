import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AddExpense = () => {
  const [groups, setGroups] = useState([]);
  const [groupId, setGroupId] = useState('');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    const fetchGroups = async () => {
      const res = await axios.get(`http://localhost:3000/api/group/user/${userId}`);
      setGroups(res.data);
    };
    fetchGroups();
  }, [userId]);

  const handleAddExpense = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3000/api/expense/add', {
        title,
        amount,
        groupId,
        paidBy: userId,
      });
      alert('Expense added');
    } catch (err) {
      alert('Failed to add expense');
    }
  };

  return (
    <form onSubmit={handleAddExpense}>
      <h3>Add Expense</h3>
      <select value={groupId} onChange={(e) => setGroupId(e.target.value)} required>
        <option value="">Select Group</option>
        {groups.map((g) => (
          <option key={g._id} value={g._id}>
            {g.name}
          </option>
        ))}
      </select>
      <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} required />
      <input type="number" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} required />
      <button type="submit">Add Expense</button>
    </form>
  );
};

export default AddExpense;
